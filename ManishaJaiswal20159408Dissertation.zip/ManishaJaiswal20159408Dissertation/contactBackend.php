<!-- START PHP Code  -->

<?php
include_once("dbConnection.php");

echo $firstname = $_POST['firstname'];
echo $lastname = $_POST['lastname'];
$country = $_POST['country'];
$subject = $_POST["subject"];

// To check input value is inserted or not

echo $firstname;
// echo $uEmail;
// echo $uPassword;

echo "insert into contacttable
(firstname, lastname, country, subject, datetime) 
value('" . $firstname . "', '" . $lastname . "', '" . $country . "', '" . $subject . "', now()) ";

$insert = mysqli_query($conn, "insert into contact
    (id, firstname, lastname, country, subject, datetime) 
    value('" . $firstname . "', '" . $lastname . "', '" . $country . "', '" . $subject . "', now()) ");
// if ($insert) {
//     // header("location: contactBackend.php");
//     // echo "Successfully Registered";
// }
