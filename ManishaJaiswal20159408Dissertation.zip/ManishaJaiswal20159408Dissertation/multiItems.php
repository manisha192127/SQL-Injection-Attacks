<?php
include_once("dbConnection.php");

session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Items</title>
    <link rel="stylesheet" href="CSS/home.css">
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="FontAwesome/fontawesome-free-5.15.3-web/css/all.css">
    <style>
        img {
            height: 90px;
            width: 100%;
        }

        .circleCard {
            width: 50px;
            height: 50px;
            border-radius: 100%;
            background: grey;
            font-size: 22px;
            text-decoration: none;
            color: white;
            display: grid;
            place-items: center;
            float: right;
        }

        .circleCard:hover {
            background: black;
            color: white;
        }
    </style>
</head>

<body>
    <!--    START GOTO TOP BUTTON-->
    <a name="top"></a>
    <!--    END GOTO TOP BUTTON-->
    <div class="container">
        <div class="row">
            <div class="text-center mt-5">
                <h2 style="color: #b502c5;">
                    Electronic Items
                </h2>
            </div>
        </div>
        <div class="row mt-3 mx-auto">
            <?php
            $select = mysqli_query($conn, "select * from category where category='electronic' or category='Electronic'");
            if (mysqli_num_rows($select) > 0) {
                while ($row = mysqli_fetch_assoc($select)) {
            ?>

                    <div class="col-12 col-md-4 col-lg-3 mx-auto my-2">
                        <div class="card p-2" style="border: 1px solid grey; border-radius: 8px; box-shadow:0 0px 20px -5px rgba(0, 0, 0, 0.8);">
                            <div class="card-body mx-auto">
                                <?php
                                if ($row['productImg'] == "" or $row['productImg'] == 'photos/') { ?>
                                    not found

                                <?php
                                } else { ?>
                                    <img src="<?= $row['productImg'] ?>">

                                <?php  }

                                ?>
                            </div>
                            <div class="mx-auto">
                                <h5>
                                    Name: <?= $row['productName'] ?>

                                </h5>
                                <h5>
                                    Price: <?= $row['price'] ?>

                                </h5>
                            </div>
                        </div>
                    </div>

            <?php }
            }
            ?>
        </div>

    </div>

    <div class="container">
        <div class="row">
            <div class="text-center mt-5">
                <h2 style="color: #b502c5;">
                    Car Items
                </h2>
            </div>
        </div>
        <div class="row mt-3 mx-auto">
            <?php
            $select = mysqli_query($conn, "select * from category where category='car'");
            if (mysqli_num_rows($select) > 0) {
                while ($row = mysqli_fetch_assoc($select)) {
            ?>

                    <div class="col-12 col-md-4 col-lg-3 mx-auto my-2">
                        <div class="card p-2" style="border: 1px solid grey; border-radius: 8px; box-shadow:0 0px 20px -5px rgba(0, 0, 0, 0.8);">
                            <div class="card-body mx-auto">
                                <?php
                                if ($row['productImg'] == "" or $row['productImg'] == 'photos/') { ?>
                                    not found

                                <?php
                                } else { ?>
                                    <img src="<?= $row['productImg'] ?>">

                                <?php  }

                                ?>
                            </div>
                            <div class="mx-auto">
                                <h5>
                                    Name: <?= $row['productName'] ?>

                                </h5>
                                <h5>
                                    Price: <?= $row['price'] ?>

                                </h5>
                            </div>
                        </div>
                    </div>

            <?php }
            }
            ?>
        </div>

    </div>

    <div class="container">
        <div class="row">
            <div class="text-center mt-5">
                <h2 style="color: #b502c5;">
                    Gift Items
                </h2>
            </div>
        </div>
        <div class="row mt-3 mx-auto">
            <?php
            $select = mysqli_query($conn, "select * from category where category='gifts'");
            if (mysqli_num_rows($select) > 0) {
                while ($row = mysqli_fetch_assoc($select)) { ?>
                    <div class="col-12 col-md-4 col-lg-3 mx-auto my-2">
                        <div class="card p-2" style="border: 1px solid grey; border-radius: 8px; box-shadow:0 0px 20px -5px rgba(0, 0, 0, 0.8);">
                            <div class="card-body mx-auto">
                                <?php
                                if ($row['productImg'] == "" or $row['productImg'] == 'photos/') { ?>
                                    not found

                                <?php
                                } else { ?>
                                    <img src="<?= $row['productImg'] ?>">

                                <?php  }

                                ?>
                            </div>
                            <div class="mx-auto">
                                <h5>
                                    Name: <?= $row['productName'] ?>

                                </h5>
                                <h5>
                                    Price: <?= $row['price'] ?>

                                </h5>
                            </div>
                        </div>
                    </div>

            <?php }
            }
            ?>
        </div>
    </div>

    <!-- START to choose electronic items -->
    <div class="container">
        <div class="row mt-5 mx-auto">
            <div class="col-8 mx-auto registrationBodyCollapse">
                <h4 class="firstHeading py-3" style="color: #b502c5;">
                    Make An Order Here
                </h4>
                <form action="selectItems.php" method="post" enctype="multipart/form-data">
                    <input class="form-control" type="file" name="productImg" placeholder="Choose file" accept="photos/*"><br>
                    <input class="form-control" type="text" name="productName" placeholder="product name"><br>
                    <input class="form-control" type="text" name="category" placeholder="category"><br>
                    <input class="form-control" type="text" name="description" placeholder="description"><br>
                    <input class="form-control" type="number" name="price" placeholder="price"><br>
                    <input class="form-control" type="text" name="available" placeholder="availability"><br>
                    <input class="form-control" type="email" name="email" placeholder="Email"><br>
                    <input class="form-control" type="number" name="phoneNo" placeholder="Contact No."><br>
                    <button class="btn btn-success px-5" style="color:chartreuse; font-weight:bold;" type="submit">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
    <!--    START GOTO TOP BUTTON-->
    <a href="#top" class="circleCard"><i class="fas fa-chevron-up"></i></a>
    <!--    START GOTO TOP BUTTON-->
    <br>
    <br>
    <br>
    <br>
    <!-- END to choose electronic items -->

    <script src="JS/JQuery.js"></script>
    <script src="JS/bootstrap.min.js"></script>
</body>

</html>