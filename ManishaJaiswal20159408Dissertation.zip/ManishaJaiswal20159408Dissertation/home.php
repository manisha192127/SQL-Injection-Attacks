<?php
include_once("dbConnection.php");

session_start();

if ($_SESSION["email_Session"] !== '' &&  isset($_SESSION["email_Session"])) {
} else {
    header("location: index.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="CSS/home.css">
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="FontAwesome/fontawesome-free-5.15.3-web/css/all.css">
    <style>
        .uName {
            font-size: 50px;
        }

        .circleCard {
            width: 50px;
            height: 50px;
            border-radius: 100%;
            background: grey;
            font-size: 22px;
            text-decoration: none;
            color: white;
            display: grid;
            place-items: center;
            float: right;
        }

        .circleCard:hover {
            background: black;
            color: white;
        }

        .myNavbar .menuItems .itemList:hover {
            color: white;
            background: #b502c5;
            padding-left: 3px;
            padding-right: 3px;
            border-radius: 5px;
            transition: 1s;
        }

        .linkClass {
            color: black;
            text-decoration: none;
        }

        .linkClass:hover {
            color: #b502c5;
            transition: 3s;
        }
    </style>
</head>

<body>
    <!--    START GOTO TOP BUTTON-->
    <a name="top"></a>
    <!--    END GOTO TOP BUTTON-->
    <!--   START  NAVBAR  -->

    <div class="myNavbar d-flex justify-content-between">
        <div class="logoImage">
            <img src="photos/sql.jpg" class="img-fluid" alt="">
        </div>

        <div class="menuItems d-none d-sm-flex">
            <a href="home.php" class="itemList">Home</a>
            <a href="multiItems.php" class="itemList">All Products</a>
            <a href="contact.php" class="itemList">Contact Us</a>
        </div>
        <!-- SIGN OUT BUTTON -->
        <a href="signOut.php" class="px-2 btn text-white btn-outline-secondary">log Out </a>
        <div class="d-flex d-sm-none">
            <button class="btn toggleBtn btn-warning" type="button" data-bs-toggle="collapse" data-bs-target="#myCollapse" aria-expanded="false" aria-controls="collapseExample">
                <i class="fas fa-bars text-danger"></i>
            </button>
        </div>
    </div>
    <!-- START COLLAPSE DROPDOWN MENU -->

    <div class="collapse" id="myCollapse">
        <div class="cardBodyCollapse">
            <a href="home.php">Home</a>
            <a href="multiItems.php">All Products</a>
            <a href="#">Contact Us</a>
        </div>
    </div>
    <!-- END COLLAPSE DROPDOWN MENU -->

    <div class="container">
        <div class="row">
            <div class="col-12 d-flex mt-3 justify-content-around firstHeading">
                <div class="col-4">
                    <img src="photos/sql.jpg" class="img-fluid" alt="">
                </div>
                <div class="mt-3 col-6 firstHeading">
                    <h1 class="uName">
                        WELCOME!<br>
                    </h1>
                    <h1 style="color: #b502c5;">
                        <?php
                        echo $_SESSION["uName_Session"];
                        ?>
                    </h1>
                    <br> <span class="text-danger">
                        <h3>
                            To Defending SQL Injection Attack
                        </h3>
                    </span>
                    <br>
                </div>
            </div>
        </div>
        <br>
        <div class="text-center p-2 " style="box-shadow:0 0px 20px -5px rgba(0, 0, 0, 0.8); background:linear-gradient(45deg, rgb(250, 8, 8), rgb(32, 32, 32)); border-radius: 8px;">
            <a href="#" class="h1" style="text-decoration: none; color:white;">Choose Category</a>
        </div>
    </div>
    <!-- START Defending Web
Application Against SQL Injection Attacks  -->
    <!-- Start 2nd SQL Injection -->

    <div class="container">
        <div class="row mt-5">
            <div class="col-12 col-md-5 col-lg-4 mx-auto">
                <div class="card" style="border: 1px solid grey; border-radius: 8px; box-shadow:0 0px 20px -5px rgba(0, 0, 0, 0.8); height:300px;">
                    <div class="card-body m-auto">
                        <img src="photos/xx1.jfif" class="img-fluid" alt="">
                    </div>
                    <div class="mx-auto d-flex p-4">
                        <a href="itemList.php?cat=Electronic" class="px-2 linkClass">
                            <h5> Electronic</h5>
                        </a>
                        <a href="multiItems.php" class="px-3 linkClass">
                            <h5>Select Items</h5>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-4 mx-auto">
                <div class="card" style="border: 1px solid grey; border-radius: 8px; box-shadow:0 0px 20px -5px rgba(0, 0, 0, 0.8); height:300px;">
                    <div class="card-body m-auto">
                        <img src="photos/car5.jfif" class="img-fluid" alt="">
                    </div>
                    <div class="d-flex mx-auto p-4">
                        <a href="itemList.php?cat=Car" class="px-2 linkClass">
                            <h5>Car</h5>
                        </a>
                        <a href="multiItems.php" class="px-2 linkClass">
                            <h5>Select Items</h5>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-4 mx-auto">
                <div class="card" style="border: 1px solid grey; border-radius: 8px; box-shadow:0 0px 20px -5px rgba(0, 0, 0, 0.8); height:300px;">
                    <div class="card-body m-auto">
                        <img src="photos/gift4.jfif" class="img-fluid" alt="">
                    </div>
                    <div class="mx-auto d-flex">
                        <a href="itemList.php?cat=Gifts" class="px-2 linkClass">
                            <h5>Gifts</h5>
                        </a>
                        <a href="multiItems.php" class="px-3 linkClass">
                            <h5>Select Items</h5>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <!--    START GOTO TOP BUTTON-->
    <a href="#top" class="circleCard"><i class="fas fa-chevron-up"></i></a>
    <!--    START GOTO TOP BUTTON-->
    <br>
    <br>
    <br>
    <!-- End 2nd SQL Injection -->
    <div class="bg-dark d-flex justify-content-between">
        <div class="logoImage">
            <img src="photos/sql.jpg" class="img-fluid" alt="">
        </div>
        <div class="text-light p-4 mt-2">
            Created By: Manisha Jaiswal <br>
            Student Id: 20159408 <br>
            Year: January, 2022 <br>
            Contact No: +44 07760512187<br>
            Email Id: Manisha.Jaiswal@mail.bcu.ac.uk
        </div>
    </div>
    <script src="JS/JQuery.js"></script>
    <script src="JS/bootstrap.min.js"></script>
</body>

</html>