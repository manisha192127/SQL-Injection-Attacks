<?php
session_start();
include_once("dbConnection.php");

$myId = $_GET['id'];

$delete = mysqli_query($conn, "delete from category where id='" . $myId . "'");

if ($delete) {
    echo "successfully deleted record";
}
