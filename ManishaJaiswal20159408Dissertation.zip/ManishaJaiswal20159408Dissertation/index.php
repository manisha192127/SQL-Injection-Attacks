<?php
include_once("dbConnection.php");
include_once("header.php");
?>

<!-- SIGN UP FORM -->

<div class="container">
    <div class="row mx-auto">
        <div class="col-6 mt-5 text-center">
            <h3 style="color: #b502c5;">
                Web Application Against SQL Injection Attacks
            </h3>
            <img src="photos/sqlinjection.jpg" width="500px" height="320px" style="border-radius: 15px;">
        </div>
        <div class="col-6">
            <div class="flex-container">
                <div class="flex-child1">

                    <form class="bodyForm1" action="signUp.php" method="post">
                        <div class="h4 myHeading mt-4 mb-4">Create New Account</div>
                        <div class="form-group">
                            <i class="fas fa-user"></i>
                            <input type="text" class="px-2" maxlength="20" minlength="4" name="myName" placeholder="User Name" required>
                        </div>
                        <label class="form-group">
                            <i class="fas fa-envelope"></i>
                            <input type="email" name="myEmail" class="px-2" placeholder="User Email" required>
                            <br>
                        </label>
                        <div class="form-group">
                            <i class="fas fa-lock"></i>
                            <input type="password" class="px-2" maxlength="15" minlength="4" name="myPassword" placeholder="User Password" required>
                        </div>
                        <div class="mt-4 form">
                            <b class="px-2"> Gender:</b>
                            <input type="radio" name="radOption" value="Male"> Male
                            <input type="radio" name="radOption" value="Female"> Female
                        </div>
                        <input type="submit" class="myBtn mt-4" value="CREATE ACCOUNT">
                    </form>
                </div>

                <?php
                if (isset($_GET["note"])) {
                    echo "Submitted successfully";
                }
                if (isset($_GET["warn"])) {
                    echo "already exist";
                }
                ?>

                <!-- START SIGN IN FORM   -->
                <div class="flex-child2">
                    <form class="bodyForm1" action="signIn.php" method="post">
                        <div class="h4 mt-4 mb-4 text-light">Login Here</div>
                        <div class="mt-3">
                            <input type="email" class="myInputField px-2" name="myEmail" placeholder="Please Enter Email">
                        </div>
                        <div class="myInputField">
                            <input class="px-2 myInputField" type="password" name="myPassword" placeholder="Please Enter Password">
                        </div>
                        <input type="submit" class="myBtn2 mt-4" value="Sign In">
                    </form>
                </div>
                <!-- END SIGN IN FORM   -->
            </div>
        </div>
    </div>
</div>


<?php
include_once("footer.php");

?>