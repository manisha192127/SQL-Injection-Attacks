<?php
include_once("dbConnection.php");


$uName = $_REQUEST["myName"];
$uEmail = $_REQUEST["myEmail"];
$uPassword = $_REQUEST['myPassword'];
$gender = $_REQUEST["radOption"];

// To check input value is inserted or not

// echo $uName;
// echo $uEmail;
// echo $uPassword;

if ((isset($uEmail) and $uEmail !== "") and (isset($uPassword) and $uPassword !== "")) {


    $signUpForm = mysqli_query($conn, "select userEmail from signUptable where userEmail =  '" . $uEmail . "' ");
    if (mysqli_num_rows($signUpForm) > 0) {

        echo "This email address is already exist";
    } else {

        $insert = mysqli_query($conn, "insert into signuptable
    (userName, userEmail, userPassword, gender, dateTime) 
    value('" . $uName . "', '" . $uEmail . "', '" . $uPassword . "', '" . $gender . "', now()) ");
        if ($insert) {
            header("location: index.php");
            // echo "Successfully Registered";
        }
    }
} else {
    echo "email field is mandatory";
}
