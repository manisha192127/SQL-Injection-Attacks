<script src="JS/JQuery.js"></script>
<script src="JS/bootstrap.min.js"></script>
</body>

</html>