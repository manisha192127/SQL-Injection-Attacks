<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignIn Page</title>
    <style>
        h1 {
            color: red;
            text-align: center;
        }

        h3 {
            color: green;
            text-align: center;
        }
    </style>
</head>

<body></body>

</html>
<?php
session_start();

include_once("dbConnection.php");

// echo $uEmail;
// echo $uPassword;


if (isset($_POST['myEmail']) and $_POST['myEmail'] !== '' and isset($_POST['myPassword']) and $_POST['myPassword'] !== '') {

    $uEmail = $_POST['myEmail'];
    $uPassword = $_POST['myPassword'];


    // echo $showdata;
    // echo $uPassword;

    // START 1st SQL Injection using malicious input is 1' or '1'='1 

    $a = str_replace(",", "", $uPassword);
    $a = str_replace(" ", "", $a);
    $a = str_replace("'", "", $a);
    $a = str_replace("=", "", $a);
    $a = str_replace("/", "", $a);
    $a = str_replace("@", "", $a);
    $a = str_replace("%", "", $a);
    $a = str_replace("!", "", $a);
    $a = str_replace("*", "", $a);
    $a = str_replace("|", "", $a);
    $a = str_replace("&", "", $a);
    $a = str_replace("?", "", $a);
    $a = str_replace(">", "", $a);
    $a = str_replace("<", "", $a);
    $a = str_replace("-", "", $a);
    $a = str_replace("+", "", $a);

    $enterMe = mysqli_query($conn, "select * from signUptable where userEmail = '" . $uEmail . "' and userPassword = '" . $a . "'");

    // END SQL Injection 


    // $enterMe = mysqli_query($conn, "select * from signUptable where userEmail = '" . $uEmail . "' and userPassword = '" . $uPassword . "'");

    if (mysqli_num_rows($enterMe) > 0) {
        $_SESSION["email_Session"] = $uEmail;

        while ($value = mysqli_fetch_assoc($enterMe)) {
            $_SESSION["uName_Session"] = $value["userName"];
            $_SESSION["myId"] = $value["id"];
        }
        header("location:home.php");
    } else {
        echo "<h1> <b> Probably SQL Injection Attack! </b></h1> <h3>Please Enter Correct Email Id and Password </h3>";
    }
}
?>