<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQL injection Sign Up page</title>
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="CSS/themeContent/signUpform.css">
    <link rel="stylesheet" href="CSS/themeContent/navbar.css">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="FontAwesome/fontawesome-free-5.15.3-web/css/all.css">
</head>

<body>