<?php

// $server = "localhost";
// $username = "root";
// $password = "";
// $first_db = "manisha20159408dissertation";

$conn = mysqli_connect("localhost", "root", "", "manisha20159408dissertation");

if ($conn->connect_error) {
    die("connection failure" . $conn->connect_error);
} else {
    // echo "Database Successfully Connected";
}
