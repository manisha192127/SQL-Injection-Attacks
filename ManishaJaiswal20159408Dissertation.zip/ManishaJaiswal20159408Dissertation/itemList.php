<?php
include_once("dbConnection.php");

session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Items</title>
    <link rel="stylesheet" href="CSS/home.css">
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="FontAwesome/fontawesome-free-5.15.3-web/css/all.css">
    <style>
        img {
            height: 90px;
            width: 100%;
        }

        .myDelete {
            text-decoration: none;
            background: green;
            color: chartreuse;
            padding: 7px 10px;
            border-radius: 7px;
            margin-top: 10px;
        }

        .myDelete:hover {
            color: white;
        }

        table {
            box-shadow: 0 0px 20px -5px rgba(0, 0, 0, 0.8);
            border-radius: 20px;
        }

        .rowTable {
            background: #d3b2e4;
            color: #9b00e8;

        }

        .circleCard {
            width: 50px;
            height: 50px;
            border-radius: 100%;
            background: grey;
            font-size: 22px;
            text-decoration: none;
            color: white;
            display: grid;
            place-items: center;
            float: right;
        }

        .circleCard:hover {
            background: black;
            color: white;
        }

        .customCard {
            position: fixed;
            right: 10px;
            top: 10px;
            height: 80px;
            width: auto;
            padding: 15px;
            background: rgba(255, 50, 50, 0.8);
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 10px lightslategray;
            display: grid;
            place-items: center;
            color: white;
        }
    </style>
</head>

<body>
    <!--    START GOTO TOP BUTTON-->
    <a name="top"></a>
    <!--    END GOTO TOP BUTTON-->
    <div class="container">
        <div class="text-center mt-5">

            <?php

            if (str_contains($_GET['cat'], '--') && isset($_GET['a'])) { ?>

                <div class="customCard">
                    SQL Injection Attack Now
                </div>
            <?php   }
            if (str_contains($_GET['cat'], '--') && !isset($_GET['a'])) { ?>
                <div class="customCard">
                    SQL Injection Prevention Now
                </div>
            <?php }

            if (strtolower($_GET['cat']) == 'electronic' || strtolower($_GET['cat']) == "electronic'--'" && !isset($_GET['a'])) { ?>
                <h2 style="color: #b502c5;">
                    Electronic Items
                </h2>
            <?php }


            if (strtolower($_GET['cat']) == 'car' || strtolower($_GET['cat']) == "car'--'" && !isset($_GET['a'])) { ?>
                <h2 style="color: #b502c5;">
                    Car Items
                </h2>
            <?php }

            if (strtolower($_GET['cat']) == 'gifts' || strtolower($_GET['cat']) == "gifts'--'" && !isset($_GET['a'])) { ?>
                <h2 style="color: #b502c5;">
                    Gift Items
                </h2>
            <?php }
            if (isset($_GET['a'])) { ?>

                <h2 style="color: #b502c5;">
                    All Item List
                </h2>
            <?php    }

            ?>
        </div>
        <div class="col-10 mt-5 mx-auto p-2">

            <table class="table text-center">
                <tr class="rowTable">
                    <th class="p-2">S.No</th>
                    <th class="p-2">Product Name</th>
                    <th class="p-2">Category</th>
                    <th class="p-2">description</th>
                    <th class="p-2">Price</th>
                    <th class="p-2">availability</th>
                    <th class="p-2">Email</th>
                    <th class="p-2">Phone No</th>
                    <th class="p-2">Time</th>
                    <th class="p-2">Action</th>
                </tr>
                <?php
                $abc = 1;

                $data =  strtolower($_GET['cat']);

                // To show SQL Injection('--') in the url put this (&a=xyz) to show sql injection

                if (isset($_GET['a'])) {

                    $a = $data;
                } else {

                    $a = str_replace(",", "", $data);
                    $a = str_replace(" ", "", $a);
                    $a = str_replace("'", "", $a);
                    $a = str_replace("=", "", $a);
                    $a = str_replace("/", "", $a);
                    $a = str_replace("@", "", $a);
                    $a = str_replace("%", "", $a);
                    $a = str_replace("!", "", $a);
                    $a = str_replace("*", "", $a);
                    $a = str_replace("|", "", $a);
                    $a = str_replace("&", "", $a);
                    $a = str_replace("?", "", $a);
                    $a = str_replace(">", "", $a);
                    $a = str_replace("<", "", $a);
                    $a = str_replace("-", "", $a);
                    $a = str_replace("+", "", $a);
                }



                $sel  = mysqli_query($conn, "select * from category where category =  '" . $a . "' ");
                if (mysqli_num_rows($sel) > 0) {
                    while ($row = mysqli_fetch_assoc($sel)) {

                ?>


                        <tr>
                            <td>
                                <?php echo $abc++; ?>
                            </td>

                            <td>
                                <?php echo $row["productName"] ?>
                            </td>
                            <td>
                                <?php echo $row["category"] ?>
                            </td>
                            <td>
                                <?php echo $row["description"] ?>
                            </td>
                            <td>
                                <?php echo $row["price"] ?>
                            </td>
                            <td>
                                <?php echo $row["available"] ?>
                            </td>
                            <td>
                                <?php echo $row["email"] ?>
                            </td>
                            <td>
                                <?php echo $row["phoneNo"] ?>
                            </td>
                            <td>
                                <?php echo $row["dateTime"] ?>
                            </td>
                            <td>
                                <div class="mt-4">
                                    <a href="delete.php?id=<?= $row["id"] ?>" class="myDelete">Delete</a>
                                </div>
                            </td>
                        </tr>
                <?php }
                }
                ?>
            </table>
        </div>
    </div>
    <!--    START GOTO TOP BUTTON-->
    <a href="#top" class="circleCard"><i class="fas fa-chevron-up"></i></a>
    <!--    START GOTO TOP BUTTON-->

    <script src="JS/JQuery.js"></script>
    <script src="JS/bootstrap.min.js"></script>
</body>

</html>
<script>
    const myTimeout = setTimeout(myGreeting, 5000);

    function myGreeting() {
        $(".customCard").hide();
    }
</script>