<?php
session_start();
include_once("dbConnection.php");



// $fileName = $_FILES['productImg']['name'];
// $tmp_name = $_FILES['productImg']['tmp_name'];
// $path_dir = "photos/" . basename($fileName);
// move_uploaded_file($tmp_name, $path_dir);

// echo "<pre>";
// print_r($_FILES);


echo $fileName = $_FILES['productImg']['name'];
echo $tmp_name = $_FILES['productImg']['tmp_name'];

$path_dir = "photos/" . basename($fileName);
move_uploaded_file($tmp_name, $path_dir);

$userName = $_POST['productName'];
$category = strtolower($_POST['category']);
$description = $_POST['description'];
$price = $_POST['price'];
$available = $_POST['available'];
$email = $_POST['email'];
$phoneNo = $_POST['phoneNo'];

$insert = mysqli_query($conn, " insert into category(productImg, productName, category, description, price, available, email, phoneNo, dateTime)
values('" . $path_dir . "', '" . $userName . "', '" . $category . "', '" . $description . "', '" . $price . "', '" . $available . "', '" . $email . "', '" . $phoneNo . "', now())
");

if ($insert) {
    header("location: home.php");

    // echo "successful";
} else {
    echo "error";
}
